package com.Service;

import java.util.ArrayList;
import java.util.Scanner;

import com.DAO.DAO_player;
import com.DTO.DTO_player;

public class LogIn {

	public String logIn() {

		Scanner sc = new Scanner(System.in);
		String id = "";
		
		while (true) {
			
			System.out.println("\n==�α���==");
			System.out.print("ID >> ");
			id = sc.next();
			System.out.print("PW >> ");
			String pw = sc.next();
			
			DAO_player dao_player = new DAO_player();
			DTO_player dto_player = dao_player.oneSelect_dao(id);
			ArrayList<DTO_player> idConfirm = dao_player.allSelect_dao();
			boolean[] idConArr = new boolean[idConfirm.size()];
			int countIdConfirm = 0;
			for (int i = 0; i < idConArr.length; i++) {
				idConArr[i] = id.equals(idConfirm.get(i).getId());
				if (idConArr[i]) {
					countIdConfirm++;
				}
			}
			if (countIdConfirm > 0) {
				if (pw.equals(dto_player.getPw())) {
					System.out.println("\n�α��� ����\n");
					break;
					
				} else {
					System.out.println("\n��й�ȣ�� Ʋ�Ƚ��ϴ�.\n");
				}
			} else {
				System.out.println("\n�������� �ʴ� ID �Դϴ�.\n");
			}
			
			
		}
		return id;

	}

}
