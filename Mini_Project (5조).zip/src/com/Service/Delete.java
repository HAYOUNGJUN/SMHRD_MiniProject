package com.Service;


import com.DAO.DAO_review;

public class Delete {

	public void delete_DB(String id) {

		DAO_review dao_review = new DAO_review();
		dao_review.delete_dao(id);

	}

}
