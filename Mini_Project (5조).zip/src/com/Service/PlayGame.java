package com.Service;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import com.DAO.DAO_music;
import com.DAO.DAO_player;
import com.DAO.DAO_review;
import com.DTO.DTO_music;
import com.DTO.DTO_player;

import javazoom.jl.player.MP3Player;

public class PlayGame {

	public void playGame(String id, int yearCategory) {

		Scanner sc = new Scanner(System.in);
		Random r = new Random();
		MP3Player mp3 = new MP3Player();
		DAO_player dao_player = new DAO_player();
		DTO_player dto_player = dao_player.oneSelect_dao(id);

		int cnt = 0;
		int[] randomNumArr = new int[10];
		String[] scoreArr = new String[10];
		String[] answerEmoticon = { "//(^��^)//", "( //�� �� ��// )", "(@^��^@)", "��(( �� �� ��))��", "��(^��^)��", "///��(���)��///",
				"///��( �� �� �� )��///", "(���� �� ����)", "��( �� �� ��)��", "(@ >_< @)" };

		for (int i = 0; i < randomNumArr.length; i++) {
			randomNumArr[i] = r.nextInt(25) + yearCategory;
			for (int j = 0; j < i; j++) {
				if (randomNumArr[i] == randomNumArr[j]) {
					i--;
					break;
				}
			}
		}

		System.out.println("\nGAME START!!\n");

		while (cnt < 10) {

			DAO_music dao_music = new DAO_music();
			DTO_music dto_music = dao_music.oneSelect_dao(randomNumArr[cnt]);

			try {
				TimeUnit.MILLISECONDS.sleep(500);

			} catch (Exception e) {
				e.printStackTrace();
			}

			if (mp3.isPlaying()) {
				mp3.stop();
			}
			System.out.println((cnt + 1) + "�� �ۢܢ�~");
			mp3.play(dto_music.getAddress());
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (Exception e) {
				e.printStackTrace();
			}
			mp3.stop();
//			if (cnt == 0) {
//				sc.nextLine();
//			}
			System.out.print("���� >> ");
			String answer = sc.nextLine();

			String answerSE = "C:\\Users\\SMHRD\\Desktop\\music\\�����Դϴ�.mp3";
			String wrongSE = "C:\\Users\\SMHRD\\Desktop\\music\\��.mp3";

			if (dto_music.getTitle().equals(answer)) {
				System.out.println("�����Դϴ�");
				System.out.println(answerEmoticon[r.nextInt(10)]+"\n");
				mp3.play(answerSE);
				scoreArr[cnt] = "O";
				try {
					TimeUnit.SECONDS.sleep(1);

				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("��!\n");
				mp3.play(wrongSE); // 1��¥���� �ٲٱ�
				scoreArr[cnt] = "X";
				try {
					TimeUnit.SECONDS.sleep(1);

				} catch (Exception e) {
					e.printStackTrace();
				}
				DAO_review dao_review = new DAO_review();
				dao_review.insert_dao(id, dto_player.getNick(), dto_music.getMusicNumber());
			}

			cnt++;
		}
		int scoreCount = 0;
		int scoreSum = 0;
		int score = 0;
		for (int i = 0; i < scoreArr.length; i++) {
			if (scoreArr[i].equals("O")) {
				scoreCount++;
				scoreSum += scoreCount;
			} else if (scoreArr[i].equals("X")) {
				scoreCount = 0;
			}
		}
		score = scoreSum * 10;
		System.out.println("SCORE : " + score + "��");
		int updateConfirm = 0;
		if (score > dto_player.getScore()) {
			updateConfirm = dao_player.update_dao(id, score);
		}
		if (updateConfirm > 0) {
			System.out.println("\n\n�ű�� ����!!\n");
		}

		while (true) {

			System.out.println("\n�����Ʈ Ȯ��");
			System.out.print("[1]Yes  [2]No  >>  ");
			int input3 = sc.nextInt();
			if (input3 == 1) {

				Review join = new Review();
				join.getReview_DB(id);
				break;

			} else if (input3 == 2) {

				System.out.println("��Ű...");
				break;

			} else {

				System.out.println("�߸��� �Է��Դϴ�.");

			}

		}

		Delete del = new Delete();
		del.delete_DB(id);

	}

}
