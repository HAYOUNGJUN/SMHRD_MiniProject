package com.Service;

import java.util.ArrayList;
import java.util.Scanner;

import com.DAO.DAO_player;
import com.DTO.DTO_player;

public class Join {

	public void getJoin_DB() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("==ȸ�� ����==");
		System.out.print("ID >> ");
		String id = sc.next();
		System.out.print("PW >> ");
		String pw = sc.next();
		System.out.print("NICKNAME >> ");
		String nick = sc.next();
		int score = 0;

		
		DTO_player dto = new DTO_player(id, pw, nick, score);
		DAO_player dao = new DAO_player();
		
		ArrayList<DTO_player> idConfirm = dao.allSelect_dao();
		boolean[] idConArr = new boolean[idConfirm.size()];
		int countIdConfirm = 0;
		for (int i = 0; i < idConArr.length; i++) {
			idConArr[i] = id.equals(idConfirm.get(i).getId());
			if (idConArr[i]) {
				countIdConfirm++;
			}
		}
		
		int cnt = 0;
		
		if (countIdConfirm == 0) {
			
			cnt = dao.insert_dao(dto);
			if (cnt > 0) {
				System.out.println("\nȸ������ ����\n");
			} else {
				System.out.println("\nȸ������ ����\n");
			}
			
		} else {
			System.out.println("\n�̹� �����ϴ� ID �Դϴ�.\n");
		}
		
		
	}

}
