package com.Service;

import java.util.ArrayList;
import java.util.Scanner;

import com.DAO.DAO_player;
import com.DAO.DAO_review;
import com.DTO.DTO_player;
import com.DTO.DTO_review;

import javazoom.jl.player.MP3Player;

public class Review {

	public void getReview_DB(String id) {
		// ����ڿ��� ID���� �Է¹޾�
		// �ش��ϴ� ID���� ������ �ܼ�â�� ����Ͻÿ�.

		Scanner sc = new Scanner(System.in);
		DAO_review dao_review = new DAO_review();
		ArrayList<DTO_review> reviewList = dao_review.joinSelect_dao(id);

		System.out.println("\nNUM\tTITLE\t\t\tSINGER");

		for (int i = 0; i < reviewList.size(); i++) {

			// System.out.print(reviewList.get(i).getTitle() + "\t" +
			// reviewList.get(i).getSinger());
			System.out.print((i + 1) + "\t");
			System.out.printf("%-30s\t", reviewList.get(i).getTitle());
//			for (int s = 0; s < 30 - reviewList.get(i).getTitle().length(); s++) {
//				System.out.printf(" ");
//			}
			System.out.printf("%-30s\n", reviewList.get(i).getSinger());
		}

		while (true) {

			System.out.println("\nƲ�� �뷡 ������?");
			System.out.print("[1]Yes  [2]No  >>  ");
			int input = sc.nextInt();
			int stopSignal = 0;
			if (input == 1) {
				while (true) {
					System.out.print("\n�� ��° �뷡�ΰ���? >>  ");
					int songNumber = sc.nextInt();
					if (songNumber <= reviewList.size()) {

						MP3Player mp3 = new MP3Player();
						if (mp3.isPlaying()) {
							mp3.stop();
						}
						mp3.play(reviewList.get(songNumber - 1).getAddress());

						System.out.println("\n< " + reviewList.get(songNumber - 1).getTitle() + " - "
								+ reviewList.get(songNumber - 1).getSinger() + " >");
						System.out.println();

						while (true) {
							
							System.out.print("[1]�ٸ� �뷡 ���  [2]�ʱ� ȭ������  >>  ");
							stopSignal = sc.nextInt();
							if (stopSignal == 1) {
								if (mp3.isPlaying()) {
									mp3.stop();
								}
								break;
							} else if (stopSignal == 2) {
								System.out.println("\n����\n");
								if (mp3.isPlaying()) {
									mp3.stop();
								}
								break;
							} else {
								System.out.println("\n�߸��� �Է��Դϴ�.\n");
							}
							
						}

					} else {
						System.out.println("\n�߸��� �Է��Դϴ�.");
					}
					if (stopSignal == 2) {
						break;
					}
				}
				if (stopSignal == 2) {
					break;
				}

			} else if (input == 2) {
				System.out.println("\n��ŷ...\n");
				break;
			} else {
				System.out.println("\n�߸��� �Է��Դϴ�.\n");
			}

		}

	}
}
