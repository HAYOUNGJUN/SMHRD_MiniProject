package com.Service;

import java.util.ArrayList;

import com.DAO.DAO_player;
import com.DTO.DTO_player;

public class Rank {

	public void getRank_DB() {

		DAO_player dao = new DAO_player();
		ArrayList<DTO_player> list = dao.allSelect_dao();
		
		System.out.println("==========================");
		System.out.println("RANK \t NICK \t SCORE");
		System.out.println("==========================");
		for (int i = 0; i < list.size(); i++) {
			System.out.println((i+1) + "\t " + list.get(i).getNick() + "\t " + list.get(i).getScore());
			
		}
		System.out.println("\n\n\n\n");
		
	}

}
