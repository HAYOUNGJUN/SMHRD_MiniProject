package com.DTO;

public class DTO_review {

	
	private String nick;
	private String title;
	private String singer;
	private String address;
	
	public DTO_review(String nick, String title, String singer, String address) {
		this.nick = nick;
		this.title = title;
		this.singer = singer;
		this.address = address;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSinger() {
		return singer;
	}

	public void setSinger(String singer) {
		this.singer = singer;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
}
