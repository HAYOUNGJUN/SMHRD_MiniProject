package com.DTO;

public class DTO_music {
	
	private int musicNumber;
	private int year;
	private String title;
	private String singer;
	private String address;
	
	public DTO_music(int musicNumber, int year, String title, String singer, String address) {
		this.musicNumber = musicNumber;
		this.year = year;
		this.title = title;
		this.singer = singer;
		this.address = address;
	}

	public int getMusicNumber() {
		return musicNumber;
	}

	public void setMusicNumber(int musicNumber) {
		this.musicNumber = musicNumber;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSinger() {
		return singer;
	}

	public void setSinger(String singer) {
		this.singer = singer;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
}
