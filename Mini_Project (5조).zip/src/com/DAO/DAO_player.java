package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.DTO.DTO_player;

public class DAO_player extends DAO {
	// DAO(Data Access Object)
	// ���񽺿��� �����ͺ��̽��� ����ǰų� Ʈ�����ǵǴ�
	// ��ɵ��� ��Ƶδ� Ŭ��������


	public int insert_dao(DTO_player dto_player) {

		try {
			getConn();

			String sql = "insert into player values(?, ?, ?, ?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto_player.getId());
			psmt.setString(2, dto_player.getPw());
			psmt.setString(3, dto_player.getNick());
			psmt.setInt(4, dto_player.getScore());

			// ���� ������ ���� ����
			cnt = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return cnt;

	}

	public int delete_dao(String id) {

		try {
			getConn();

			String sql = "delete from player where id = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);

			cnt = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}

	public int update_dao(String id, int score) {

		try {
			getConn();

			String sql = "update player set score = ? where id = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, score);
			psmt.setString(2, id);

			cnt = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return cnt;

	}

	public DTO_player oneSelect_dao(String id) {

//		String str_sum = "";
//		String[] str_arr = new String[3];

		DTO_player dto_player = null;

		try {
			getConn();

			String sql = "select * from player where id = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);

			rs = psmt.executeQuery();

			while (rs.next()) {
				String getid = rs.getString(1);
				String pw = rs.getString(2);
				String nick = rs.getString(3);
				int score = rs.getInt(4);

				dto_player = new DTO_player(getid, pw, nick, score);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return dto_player;

	}

	public ArrayList<DTO_player> allSelect_dao() {

		ArrayList<DTO_player> list = new ArrayList<DTO_player>();

		try {
			getConn();

			String sql = "select * from player order by score desc";
			psmt = conn.prepareStatement(sql);
	
			rs = psmt.executeQuery();
			// rs --> �����ͺ��̽��� ǥ�� ���� ����

			while (rs.next()) {
				// rs.next() -> cursor�� ��ĭ ������ ������!
				String id = rs.getString("id");
				String pw = rs.getString("pw");
				String nick = rs.getString("nick");
				int score = rs.getInt("score");

				DTO_player dto_player = new DTO_player(id, pw, nick, score);
				// table �ȿ��� �� �ϳ��� �� �����͸� ��������
				list.add(dto_player);
				// �� �����͸� �ϳ��� �߰��ؼ� table�� ���� ���¸� ������ֱ�
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			close();
		}

		return list;

	}

}
