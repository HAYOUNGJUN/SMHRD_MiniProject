package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.DTO.DTO_music;
import com.DTO.DTO_player;

public class DAO_music extends DAO {
	// DAO(Data Access Object)
	// ���񽺿��� �����ͺ��̽��� ����ǰų� Ʈ�����ǵǴ�
	// ��ɵ��� ��Ƶδ� Ŭ��������


	public int insert_dao(DTO_music dto_music) {

		try {
			getConn();

			String sql = "insert into music values(?, ?, ?, ?, ?)";
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, dto_music.getMusicNumber());
			psmt.setInt(2, dto_music.getYear());
			psmt.setString(3, dto_music.getTitle());
			psmt.setString(4, dto_music.getSinger());
			psmt.setString(5, dto_music.getAddress());

			// ���� ������ ���� ����
			cnt = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return cnt;

	}

	public int delete_dao(String title) {

		try {
			getConn();

			String sql = "delete from music where title = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, title);

			cnt = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}

//	public int update_dao(String id, String pw) {
//
//		try {
//			getConn();
//
//			String sql = "update member set pw = ? where id = ?";
//			psmt = conn.prepareStatement(sql);
//			psmt.setString(1, pw);
//			psmt.setString(2, id);
//
//			cnt = psmt.executeUpdate();
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			close();
//		}
//
//		return cnt;
//
//	}
	
	public DTO_music oneSelect_dao(int musicNumber) {
		
//		String str_sum = "";
//		String[] str_arr = new String[3];
		
		DTO_music dto_music = null;
		
		try {
			getConn();

			String sql = "select * from music where music_number = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, musicNumber);

			rs = psmt.executeQuery();

			while (rs.next()) {
				int getMusicNumber = rs.getInt(1);
				int year = rs.getInt(2);
				String title = rs.getString(3);
				String singer = rs.getString(4);
				String address = rs.getString(5);

				dto_music = new DTO_music(getMusicNumber, year, title, singer, address);
				
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		return dto_music;
		
	}
	
	public ArrayList<DTO_music> allSelect_dao() {
		
		ArrayList<DTO_music> list = new ArrayList<DTO_music>();
		
		try {
			getConn();

			String sql = "select * from music";
			psmt = conn.prepareStatement(sql);

			rs = psmt.executeQuery();
			// rs --> �����ͺ��̽��� ǥ�� ���� ����

			while (rs.next()) {
				// rs.next() -> cursor�� ��ĭ ������ ������!
				int getMusicNumber = rs.getInt(1);
				int year = rs.getInt(2);
				String title = rs.getString(3);
				String singer = rs.getString(4);
				String address = rs.getString(5);
				
				DTO_music dto_music = new DTO_music(getMusicNumber, year, title, singer, address);
				// table �ȿ��� �� �ϳ��� �� �����͸� ��������
				list.add(dto_music);
				// �� �����͸� �ϳ��� �߰��ؼ� table�� ���� ���¸� ������ֱ�
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			close();
		}
		
		return list;

	}
}
