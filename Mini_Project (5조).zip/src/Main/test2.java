package Main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import com.DAO.DAO_music;
import com.DAO.DAO_player;
import com.DAO.DAO_review;
import com.DTO.DTO_music;
import com.DTO.DTO_player;
import com.DTO.DTO_review;
import com.Service.Rank;
import com.Service.Delete;
import com.Service.Join;
import com.Service.Review;

import javazoom.jl.player.MP3Player;

public class test2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("==KIMHEECHUL GAME==");

		while (true) {
			int input = 0;
			int input2 = 0;
			while (true) {
				System.out.print("[1]�α���  [2]ȸ������  [3]����  >>  ");
				input = sc.nextInt();
				if (input == 1) {

					System.out.println("==�α���==");
					System.out.print("ID >> ");
					String id = sc.next();
					System.out.print("PW >> ");
					String pw = sc.next();

					DAO_player dao_player = new DAO_player();
					DTO_player dto_player = dao_player.oneSelect_dao(id);
					ArrayList<DTO_player> idConfirm = dao_player.allSelect_dao();
					boolean[] idConArr = new boolean[idConfirm.size()];
					int countIdConfirm = 0;
					for (int i = 0; i < idConArr.length; i++) {
						idConArr[i] = id.equals(idConfirm.get(i).getId());
						if (idConArr[i]) {
							countIdConfirm++;
						}
					}
					if (countIdConfirm > 0) {
						if (pw.equals(dto_player.getPw())) {
							System.out.println("�α��� ����");

							while (true) {

								System.out.print("[1]���� ����  [2]��ŷ Ȯ��  [3]�α׾ƿ�  >>  ");
								input2 = sc.nextInt();

								if (input2 == 1) {
									System.out.println("GAME START!");
									MP3Player mp3 = new MP3Player();
									Random r = new Random();
									int cnt = 0;

									System.out.println("������ �����ϼ���.");
									System.out.print("[1]1990  [2]2000  [3]2010 >> ");
									int selectYear = sc.nextInt();

									int[] randomNumArr = new int[10];
									String[] scoreArr = new String[10];

									if (selectYear == 1) {

										for (int i = 0; i < randomNumArr.length; i++) {
											randomNumArr[i] = r.nextInt(25) + 1;
											for (int j = 0; j < i; j++) {
												if (randomNumArr[i] == randomNumArr[j]) {
													i--;
													break;
												}
											}
										}

										while (cnt < 10) {

											DAO_music dao_music = new DAO_music();
											DTO_music dto_music = dao_music.oneSelect_dao(randomNumArr[cnt]);

											if (mp3.isPlaying()) {
												mp3.stop();
											}

											System.out.println(dto_music.getAddress());
											mp3.play(dto_music.getAddress());
											try {
												TimeUnit.SECONDS.sleep(3);
											} catch (Exception e) {
												e.printStackTrace();
											}
											mp3.stop();
											if (cnt == 0) {
												sc.nextLine();
											}
											System.out.println("������ �Է��ϼ���.");
											String answer = sc.nextLine();
											if (dto_music.getTitle().equals(answer)) {
												System.out.println("�����Դϴ�");
												scoreArr[cnt] = "O";
											} else {
												System.out.println("��!");
												scoreArr[cnt] = "X";
												DAO_review dao_review = new DAO_review();
												dao_review.insert_dao(id, dto_player.getNick(), dto_music.getMusicNumber());
											}

											cnt++;
										}
										int scoreCount = 0;
										int scoreSum = 0;
										int score = 0;
										for (int i = 0; i < scoreArr.length; i++) {
											if (scoreArr[i].equals("O")) {
												scoreCount++;
												scoreSum += scoreCount;
											} else if (scoreArr[i].equals("X")) {
												scoreCount = 0;
											}
										}
										score = scoreSum * 10;
										int updateConfirm = 0;
										if (score > dto_player.getScore()) {
											updateConfirm = dao_player.update_dao(id, score);
										}
										if (updateConfirm > 0) {
											System.out.println("�ű�� ����!!");
										}
										
										System.out.println("�����Ʈ Ȯ��");
										System.out.println("[1]Yes  [2]No  >>  ");
										int input3 = sc.nextInt();
										if (input3 == 1) {
											
											Review join = new Review();
											join.getReview_DB(id);
											
										} else {
											System.out.println("��Ű...");
										}
										
										Delete del = new Delete();
										del.delete_DB(id);
										

									} else if (selectYear == 2) {

										for (int i = 0; i < randomNumArr.length; i++) {
											randomNumArr[i] = r.nextInt(25) + 26;
											for (int j = 0; j < i; j++) {
												if (randomNumArr[i] == randomNumArr[j]) {
													i--;
													break;
												}
											}
										}

										while (cnt < 10) {

											DAO_music dao_music = new DAO_music();
											DTO_music dto_music = dao_music.oneSelect_dao(randomNumArr[cnt]);

											if (mp3.isPlaying()) {
												mp3.stop();
											}

											System.out.println(dto_music.getAddress());
											mp3.play(dto_music.getAddress());
											try {
												TimeUnit.SECONDS.sleep(3);
											} catch (Exception e) {
												e.printStackTrace();
											}
											mp3.stop();
											if (cnt == 0) {
												sc.nextLine();
											}
											System.out.println("������ �Է��ϼ���.");
											String answer = sc.nextLine();
											if (dto_music.getTitle().equals(answer)) {
												System.out.println("�����Դϴ�");
												scoreArr[cnt] = "O";
											} else {
												System.out.println("��!");
												scoreArr[cnt] = "X";
												DAO_review dao_review = new DAO_review();
												dao_review.insert_dao(id, dto_player.getNick(), dto_music.getMusicNumber());
											}

											cnt++;
										}
										int scoreCount = 0;
										int scoreSum = 0;
										int score = 0;
										for (int i = 0; i < scoreArr.length; i++) {
											if (scoreArr[i].equals("O")) {
												scoreCount++;
												scoreSum += scoreCount;
											} else if (scoreArr[i].equals("X")) {
												scoreCount = 0;
											}
										}
										score = scoreSum * 10;
										int updateConfirm = 0;
										if (score > dto_player.getScore()) {
											updateConfirm = dao_player.update_dao(id, score);
										}
										if (updateConfirm > 0) {
											System.out.println("�ű�� ����!!");
										}
										
										System.out.println("�����Ʈ Ȯ��");
										System.out.println("[1]Yes  [2]No  >>  ");
										int input3 = sc.nextInt();
										if (input3 == 1) {
											
											Review join = new Review();
											join.getReview_DB(id);
											
										} else {
											System.out.println("��Ű...");
										}
										
										Delete del = new Delete();
										del.delete_DB(id);

									} else if (selectYear == 3) {

										for (int i = 0; i < randomNumArr.length; i++) {
											randomNumArr[i] = r.nextInt(25) + 51;
											for (int j = 0; j < i; j++) {
												if (randomNumArr[i] == randomNumArr[j]) {
													i--;
													break;
												}
											}
										}

										while (cnt < 10) {

											DAO_music dao_music = new DAO_music();
											DTO_music dto_music = dao_music.oneSelect_dao(randomNumArr[cnt]);

											if (mp3.isPlaying()) {
												mp3.stop();
											}

											System.out.println(dto_music.getAddress());
											mp3.play(dto_music.getAddress());
											try {
												TimeUnit.SECONDS.sleep(3);
											} catch (Exception e) {
												e.printStackTrace();
											}
											mp3.stop();
											if (cnt == 0) {
												sc.nextLine();
											}
											System.out.println("������ �Է��ϼ���.");
											String answer = sc.nextLine();
											if (dto_music.getTitle().equals(answer)) {
												System.out.println("�����Դϴ�");
												scoreArr[cnt] = "O";
											} else {
												System.out.println("��!");
												scoreArr[cnt] = "X";
												DAO_review dao_review = new DAO_review();
												dao_review.insert_dao(id, dto_player.getNick(), dto_music.getMusicNumber());
											}

											cnt++;
										}
										int scoreCount = 0;
										int scoreSum = 0;
										int score = 0;
										for (int i = 0; i < scoreArr.length; i++) {
											if (scoreArr[i].equals("O")) {
												scoreCount++;
												scoreSum += scoreCount;
											} else if (scoreArr[i].equals("X")) {
												scoreCount = 0;
											}
										}
										score = scoreSum * 10;
										int updateConfirm = 0;
										if (score > dto_player.getScore()) {
											updateConfirm = dao_player.update_dao(id, score);
										}
										if (updateConfirm > 0) {
											System.out.println("�ű�� ����!!");
										}
										
										System.out.println("�����Ʈ Ȯ��");
										System.out.println("[1]Yes  [2]No  >>  ");
										int input3 = sc.nextInt();
										if (input3 == 1) {
											
											Review join = new Review();
											join.getReview_DB(id);
											
										} else {
											System.out.println("��Ű...");
										}
										
										Delete del = new Delete();
										del.delete_DB(id);

									} else {
										System.out.println("�߸��� �Է��Դϴ�.");
									}

								}

								else if (input2 == 2) {
									System.out.println("==RANK==");
									Rank all = new Rank();
									all.getRank_DB();

								} else if (input2 == 3) {
									System.out.println("�α׾ƿ�");
									break;
								}

							}

						} else {
							System.out.println("��й�ȣ�� Ʋ�Ƚ��ϴ�.");
						}
					} else {
						System.out.println("�������� �ʴ� ID �Դϴ�.");
					}

				} else if (input == 2) {

					Join in = new Join();
					in.getJoin_DB();

				} else if (input == 3) {

					System.out.println("���� ����");
					break;

				}
			}
			if (input == 3) {
				break;
			}

			if (input2 == 3) {
				break;
			}
		}

	}

	public static int[] getRandomNumber(int count, int arrange) {

		Random r = new Random();
		int[] randomNumArr = new int[count];

		for (int i = 0; i < randomNumArr.length; i++) {

			randomNumArr[i] = r.nextInt(25) + arrange;

			for (int j = 0; j < i; j++) {

				if (randomNumArr[i] == randomNumArr[j]) {
					i--;
					break;
				}
			}
		}

		return randomNumArr;

	}

}
