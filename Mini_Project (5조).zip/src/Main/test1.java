package Main;

import java.util.Scanner;

import com.Service.Rank;
import com.Service.Join;
import com.Service.LogIn;
import com.Service.PlayGame;

public class test1 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("==KIMHEECHUL GAME==");

		while (true) {
			int input = 0;
			String id = "";
			while (true) {
				System.out.print("[1]�α���  [2]ȸ������  [3]����  >>  ");
				input = sc.nextInt();
				if (input == 1) {

					LogIn login = new LogIn();
					id = login.logIn();
					break;

				} else if (input == 2) {

					Join join = new Join();
					join.getJoin_DB();

				} else if (input == 3) {

					System.out.println("���� ����");
					break;

				} else {
					System.out.println("�߸��� �Է��Դϴ�.");
				}
			}
			if (input == 3) {
				break;
			}

			while (true) {

				System.out.print("[1]���� ����  [2]��ŷ Ȯ��  [3]����  >>  ");
				input = sc.nextInt();

				if (input == 1) {
					PlayGame game = new PlayGame();

					System.out.println("GAME START!");
					System.out.println("������ �����ϼ���.");
					System.out.print("[1]1990  [2]2000  [3]2010 >> ");
					int selectYear = sc.nextInt();

					if (selectYear == 1) {

						game.playGame(id, 1);

					} else if (selectYear == 2) {

						game.playGame(id, 26);

					} else if (selectYear == 3) {

						game.playGame(id, 51);

					} else {
						System.out.println("�߸��� �Է��Դϴ�.");
					}

				} else if (input == 2) {
					System.out.println("==RANK==");
					Rank all = new Rank();
					all.getRank_DB();

				} else if (input == 3) {
					System.out.println("���� ����");
					break;
				} else {
					System.out.println("�߸��� �Է��Դϴ�.");
				}

			}

			if (input == 3) {
				break;
			}

		}

	}

}
