package Main;

import java.util.Scanner;

import com.DAO.DAO_music;
import com.DTO.DTO_music;

public class Insert_music {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("==�뷡 DB �Է�==");
		System.out.print("music_number >> ");
		int musicNumber = sc.nextInt();
		System.out.print("year >> ");
		int year = sc.nextInt();
		System.out.print("title >> ");
		sc.nextLine();
		String title = sc.nextLine();
		System.out.print("singer >>  ");
		sc.nextLine();
		String singer = sc.nextLine();
		System.out.print("address >>  ");
		sc.nextLine();
		String address = sc.nextLine();


		DTO_music dto = new DTO_music(musicNumber, year, title, singer, address);
		DAO_music dao = new DAO_music();
		int cnt = dao.insert_dao(dto);

		if (cnt > 0) {
			System.out.println("����");
		} else {
			System.out.println("����");
		}

	}

}
